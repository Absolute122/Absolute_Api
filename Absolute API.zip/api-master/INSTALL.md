The installation documents have been moved into: [https://github.com/sodafoundation/api/wiki](https://github.com/sodafoundation/api/wiki)
