This is a CLI tool for connecting to OpenSDS client.
