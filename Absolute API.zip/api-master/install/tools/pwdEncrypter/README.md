This is a password encryption tool provided by OpenSDS. User can use this tool to get cipher text and shell scripts can call it for automatic encryption during the deployment process.

Steps for usage:

1: Use go build command to compile go source file.

2: Modify the pwdEncrypter.yaml to choose encryption tool.

3: Run ./pwdEncrypter password to get cipher text.