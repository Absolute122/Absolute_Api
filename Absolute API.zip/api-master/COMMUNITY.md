# OpenSDS Technical Meeting

Global community meeting for technical topics covering all engineering topics (Requirements, Design/Architecture, Issues, Releases, Status, Plan and Events)

## Meeting Time and Agenda
Meeting Time and Details can be found at : http://bit.ly/opensdstechmeeting

## Organizers

- [Sanil Kumar D](https://github.com/skdwriting), OpenSDS

## Contact

- [Slack](https://opensds.io/slack)
- [Mailing List](https://lists.opensds.io/g/opensds/)
